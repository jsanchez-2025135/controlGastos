import { Routes } from '@angular/router';
import { LoginComponent } from './features/auth/login/login.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { IngresosComponent } from './features/ingresos/ingresos.component';
import { EgresosComponent } from './features/egresos/egresos.component';
import { PequenosConsumosComponent } from './features/pequenos-consumos/pequenos-consumos.component';
import { TransaccionesComponent } from './features/transacciones/transacciones.component';
import { PresupuestosComponent } from './features/presupuestos/presupuestos.component';
import { ReportesComponent } from './features/reportes/reportes.component';
import { authGuard } from './core/guards/auth.guard';
import { NotificacionesComponent } from './features/notificaciones/notificaciones.component';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },

  // Ruta protegida: cualquier usuario autenticado (Admin o User)
  { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },
  { path: 'ingresos', component: IngresosComponent, canActivate: [authGuard] },
  { path: 'egresos', component: EgresosComponent, canActivate: [authGuard] },
  { path: 'pequenos-consumos', component: PequenosConsumosComponent, canActivate: [authGuard] },
  { path: 'transacciones', component: TransaccionesComponent, canActivate: [authGuard] },
  { path: 'presupuestos', component: PresupuestosComponent, canActivate: [authGuard] },
  { path: 'reportes', component: ReportesComponent, canActivate: [authGuard] },
  { path: 'notificaciones', component: NotificacionesComponent, canActivate: [authGuard] },
  // Ejemplo de ruta protegida SOLO para Admin (lista para cuando exista la vista)
  // { path: 'admin', component: AdminComponent, canActivate: [authGuard], data: { role: 'admin' } },

  { path: '**', redirectTo: 'login' },
];